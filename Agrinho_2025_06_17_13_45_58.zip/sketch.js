function setup() {
  createCanvas(800, 400);
  noLoop();
}

function draw() {
  background(135, 206, 235); // CéU

  drawCampo();
  drawCidade();
  drawEstrada();
}

//  PLAnt e TRaaaator
function drawCampo() {
  // Grama
  fill(34, 139, 34);
  rect(0, 250, 400, 150);

  // LInha 
  for (let i = 0; i < 10; i++) {
    stroke(139, 69, 19);
    line(i * 40, 250, i * 40 + 20, 400);
  }

  noStroke();

  // Trator 
  fill(255, 0, 0);
  rect(100, 220, 60, 30); 
  rect(120, 200, 30, 20); //
  fill(0);
  ellipse(110, 255, 20); 
  ellipse(150, 255, 20); // pneu direita
}

// CIIdade
function drawCidade() {
  // Asfalto
  fill(169, 169, 169);
  rect(400, 250, 400, 150);

  // Preedio
  for (let i = 0; i < 4; i++) {
    let x = 450 + i * 80;
    let h = random(100, 180);
    fill(100);
    rect(x, 250 - h, 60, h);

    // Janelas
    fill(255, 255, 0);
    for (let y = 260 - h; y < 250; y += 20) {
      rect(x + 10, y, 10, 10);
      rect(x + 35, y, 10, 10);
    }
  }
}

// rua do meio
function drawEstrada() {
  fill(50);
  rect(300, 250, 200, 150); 

  //Faixa
  stroke(255, 255, 0);// 
  strokeWeight(2);
  for (let y = 260; y < 400; y += 20) {
    line(395, y, 405, y);
  }
}
